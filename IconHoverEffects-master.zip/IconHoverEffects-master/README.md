
Icon Hover Effects
=========
A set of simple round icon hover effects with CSS transitions and animations for your inspiration.


[article on Codrops](http://tympanus.net/codrops/?p=15265)

[demo](http://tympanus.net/Development/IconHoverEffects/)

[LICENSING & TERMS OF USE](http://tympanus.net/codrops/licensing/)